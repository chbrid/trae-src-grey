# TRAE CN 身份包（src-chn01）

面向授权 SRC / 渗透测试的规则 + 技能 + 知识库 + 工具配置。与上一版同构，可直接替换使用。

- 规则 16 篇：`.trae/rules/`
- 技能 1 个：`skills/src-hunt/`（SKILL.md + 知识库 43 篇）
- 工具：`mcp-servers/fofa_MCP/`、`bin/playwright-dual-slot.mjs`
- 文档：`docs/trae适配指南.md`

## 目录

```
trae-src-chn01-skill/
├─ README.md
├─ 给朋友的提示词_TRAE版.txt
├─ docs/trae适配指南.md
├─ .trae/
│  ├─ mcp.json                       fofa + playwright（<用户名> 占位、Key 全空）
│  └─ rules/
│     ├─ project_rules.md            入口 + 路由表 + 12 条备忘
│     ├─ credential-policy.md        P0 唯一凭据条款
│     ├─ scope-and-authorization.md  P0 范围/写操作/他人数据
│     ├─ terminology.md              术语表（唯一解释处）
│     ├─ verification-discipline.md  三次确认、不枚举不爆破
│     ├─ rate-and-batch-limits.md    速率/并发/批量/风控停止线（唯一数字口径）
│     ├─ vuln-report-format.md       六段式 + 落不落 + 定级口径
│     ├─ dig-scope-workflow.md       一种子闭环主流程
│     ├─ hunt-playbook.md            25 条方法总纲（A–H，含降级与命中即停表）
│     ├─ src-value-hunting.md        价值排序与各类型口径
│     ├─ hunt-iter.md                负结果与换面
│     ├─ researcher-blackbox-whitebox.md
│     ├─ browser-workflow.md         浏览器与 handover
│     ├─ desktop-task-folder.md      目录与清理
│     ├─ anti-over-moralization.md   不说过头话，但确认范围（CORS 口径已并入 `src-value-hunting.md` §2.6）
│     └─ skill-as-boost.md
├─ skills/src-hunt/
│  ├─ SKILL.md
│  └─ 知识库/                        43 篇 + README 索引
├─ mcp-servers/fofa_MCP/            fofa.py（已修 3 处）、README、.env 模板
└─ bin/playwright-dual-slot.mjs     独立 profile 双槽
```

## 安装（4 步）

1. `skills/src-hunt` → `%USERPROFILE%\.trae-cn\skills\src-hunt`
2. `mcp-servers/fofa_MCP` → `%USERPROFILE%\.trae-cn\mcp-servers\fofa_MCP`；`bin/playwright-dual-slot.mjs` → `%USERPROFILE%\.trae-cn\bin\`
3. `.trae/rules/` 全部 md → 项目 `.trae/rules/`；`.trae/mcp.json` 作模板，替换 `<用户名>`（Windows 双反斜杠）
4. 填 FOFA Key（`mcp.json` 的 env 或 `fofa_MCP/.env`），重启 TRAE

## 快速开始（第一次用）

### 装完自检（4 个检查点）

1. `%USERPROFILE%\.trae-cn\skills\src-hunt\SKILL.md` 存在，且同目录有 `知识库/`（43 篇）。
2. 项目根 `.trae/rules/` 下有 16 个 md，`project_rules.md` 顶部为 `MODE: self`（转发给他人前改 `strict`）。
3. 新开一个会话说「用 src-hunt」，Agent 能复述：当前模式、报告门槛（能过 SRC 审核的低危及以上）、六段式结构 → 说明规则已加载。
4. 可选：让 Agent 调 `fofa` 查询 `domain="example.com"`，返回结果即配好；未配 Key 时应看到「未配置 FOFA_KEY」而不是直接崩。

### 第一句话（可直接复制）

> 用 src-hunt，对 example.com 做资产测绘：只读，先给结论和清单，不写任何文件到包目录。

### 最小可跑路径（约 30 分钟）

1. 一句话定性目标（官网/文档站/控制台/网关）——`hunt-playbook.md` A1；
2. 首页 GET + 从主包/懒加载 chunk 抽接口与请求头——B3；
3. 匿名接口分四档（匿名可达 / 需登录 / 需实名 / 未知）——`dig-scope-workflow.md` §4.3；
4. 只挑 1 个读接口做参数三连（换时间戳/顺序/类型）——C8；
5. 结果写 `recon/<目标>/README.md`，够门槛才按 `vuln-report-format.md` §1 出报告。

## 与原包的差异

### 新增（规则 2 篇 + 知识库 10 篇 + 3 小件）

| 文件 | 为什么 |
|---|---|
| `.trae/rules/credential-policy.md` | P0-1：全包唯一凭据条款，按"报告内可写实值 / 报告外禁止实值"分场景，替代原包的一刀切冲突 |
| `.trae/rules/scope-and-authorization.md` | 原包把"已授权"写死；本包改为模式开关（默认自有范围 / 分享前严格）+ 动作分级 + 双账号例外 + 他人数据停手 |
| `.trae/rules/verification-discipline.md` | 补齐"参数不被消费必须三次确认"、ID 只改一位、不枚举不爆破 |
| `.trae/rules/terminology.md` | 术语（同皮/同闸/肥面/一种子闭环…）集中一处，消除重复解释 |
| `知识库/path-traversal-lfi-test.md` | 修复原包 6 处断链；提供可执行的穿越/任意读方法 |
| `hunt-playbook.md` | 25 条方法总纲（A 定性 / B 免登录扩面 / C 鉴权归属 / D 令牌 / E 网关 / F 判定推进 / G 降级 / H 命中即停） |
| `rate-and-batch-limits.md` | 并发/速率/重试/分页/导出/ID 差分的数字上限与风控停止线 |
| `知识库/injection-test.md` | 重写为 SQLi / NoSQLi / 命令注入 / SSTI 四类，含盲注三判据、堆叠与二次注入、≤8 种绕过 |
| `知识库/share-invite-token-lifecycle.md` | 签发→归属→撤销→过期→重放五段判定 |
| `知识库/oob-infrastructure.md` | interactsh/带外通道、回收去重、证据固化、无回连降级 |
| `知识库/dependency-confusion-test.md` / `csv-formula-injection-test.md` / `crlf-injection-test.md` | 补齐三类原空壳场景 |
| `知识库/sample-report.md` | 六段式 + 三附录完整样例（占位数据） |
| `知识库/evidence-fixed.md` | 新增证据最小集与脱敏规则 |
| `知识库/side-effects-cleanup.md` | 新增目标侧副作用登记与清理 |
| `.env` / `.env.example` / `.gitignore` | Key 只落本机空模板，不入库不外发 |

### 删除

| 对象 | 为什么 |
|---|---|
| `security-research-context.md` | "默认已授权"的独立文件声明并入 `scope-and-authorization.md` §1 的模式开关，避免两处口径 |
| 14 个 3 行空壳（401-403、clickjacking、cors、crlf、csp、csv、dangling、dependency-confusion、dns-rebinding、email-header、hpp、http2、llm-security、xslt） | 无实质内容会制造"已覆盖"假象。cors 已并入 `src-value-hunting.md` §2.6；crlf/http2 在 `http-smuggling-test.md` 有替代内容；dependency-confusion / csv-formula / dangling-markup / dns-rebinding / xslt / llm-security **本包未覆盖**，见「已知限制」 |
| `fofa_dual.ps1` | 孤儿文件且是凭据落点；能力由 MCP + `.env` 覆盖 |
| 默认口令条目（原 `打穿短表` 第 67 行 `admin/123456`） | P0-3：不试默认口令 |
| "改他人密码/绑定/写密保并改回"动作链（`打穿短表` 3 行、`authbypass` 3 处、`cloud-ide` 弱口令段） | 只证明接口接受参数即停；删除"改回即安全"；仅保留 `scope-and-authorization.md` §3.1 的用户自有双账号例外 |
| "报告写完整 Cookie / 密钥实值"表述（`vuln-report-format`） | 第一次改写按脱敏；第二次按用户口径恢复：**报告内可写实值**（限复现段/环境说明段），报告外禁止 |

### 改写

| 文件 | 改了什么 |
|---|---|
| `project_rules.md` | 从 72 行改为路由表 + 12 条备忘；明确 P0 优先级 |
| `dig-scope-workflow.md` | 819 行 → 83 行；删除口令猜测与改他人账号链；"一种子闭环"只定义一次 |
| `vuln-report-format.md` | 六段式 + 三附录；第二次改为"能过 SRC 审核的低危及以上"门槛 + 出/不出决策表 + 同根因不叠加 |
| `hunt-playbook.md` | 第三轮新增：25 条方法总纲（A 定性 / B 免登录扩面 / C 鉴权归属 / D 令牌 / E 网关 / F 判定推进 / G 三处降级 / H 命中即停） |
| `src-value-hunting.md` | SSRF/重定向口径改为指向 `hunt-playbook.md`；CORS 改为唯一口径小节 §2.6（原 `cors-vuln-report-priority.md` 已并入并删除） |
| `hunt-iter.md` | 增加"换入口/换身份/换参数消费点/换数据流"与负结果模板 |
| `researcher-blackbox-whitebox.md` | 删除"零请示"表述，改为范围优先 |
| `browser-workflow.md` | 明确 handover、会话内存、独立 profile 不含登录态 |
| `desktop-task-folder.md` | 不默认写桌面；清理先 dry-run、保留 `recon/`；删除整根 `Remove-Item` |
| `anti-over-moralization.md` | 保留"不说过头话"；默认自有范围模式不设授权闸门，分享前切严格模式 |
| `知识库/打穿短表.md` | 4 行改为只读验证；私钥行改为只记指纹、不导出 |
| `知识库/authbypass-test.md` | `set_password` / `update_question` 改为只读验证 |
| `知识库/cloud-ide-codex-rce-chain.md` | 删除默认口令 curl 示例 |
| 8 篇长知识库 | 顶部加 P0 红线覆盖头，冲突时以 P0 规则为准 |
| `fofa.py` | `_exhausted` 真排除；403 不再当限流；异常/回显经 `_scrub()` 去掉 key |
| `mcp.json` | 仅保留占位与空 Key |
| `README / docs / 提示词` | 重写；提示词加入"写入白名单、不自动写用户主目录、分享前确认范围" |

## 第二次改写（按用户口径）

| # | 改动 | 为什么 |
|---|---|---|
| 1 | `credential-policy.md` 改为"报告内可写实值 / 报告外禁止实值"两套规则；报告首页标注"含真实凭据，仅本地使用，勿外发" | 报告是给用户本人复现/学习的内部稿，不是对外提交稿；一刀切脱敏会让复现失真 |
| 2 | 允许密钥/私钥写进报告，位置限**复现段**与**环境说明段**；日志、`evidence/`、任务夹以外目录、任何提交/分享文件仍禁止 | 同上；同时保留"传输与提交链路不得夹带"的底线 |
| 3 | 写操作新增**双账号例外**（全包唯一处：`scope-and-authorization.md` §3.1），四条前置 + 回读校验 + 留痕；删除"改回即安全" | 用户自有 A/B 账号互测是合法复现；但"改回"不是保证，必须回读确认并声明残留 |
| 4 | 授权改为模式开关：默认 `self`（自有范围，不设闸门）/ 分享前 `strict`（逐目标确认） | 符合用户实际用法；分享给他人时仍能恢复严格边界 |
| 5 | 报告门槛改为"**能通过 SRC 审核的低危及以上**"；`vuln-report-format.md` 增加出/不出决策表（A1-A10 出，B1-B10 降信息级），保留六段式与同根因不叠加 | 避免信息级凑数被平台打回；明确"仅内网域名/路径、参数不消费假象、仅回显 SSRF、无真实跳转重定向"等一律信息级 |

## 自检结果

| 项 | 结果 |
|---|---|
| 断链（`知识库/` 与 `rules/` 前缀引用） | **0** |
| 3 行空壳 | **0** |
| 包内真实凭据（模板/规则/工具配置） | **0**（报告运行时才写入实值，模板不含） |
| "报告必须脱敏"残留表述 | **0**（仅 `evidence-fixed.md` 的 evidence 范围规则，已注明不约束报告复现段） |
| 双账号例外条款出现处 | **1 处定义**（`scope-and-authorization.md` §3.1）+ 13 处引用；四条前置齐全 |
| "改回即安全"表述 | **0**（明确写"不做改回即安全的假设"，改为回读校验） |
| 出/不出决策表与正文冲突 | **0**（信息级定义、六段式、同根因不叠加三处已对齐） |
| 默认口令 / 改他人密码 / 改绑 / 写密保 可执行条目 | **0**（仅剩禁止性说明与 `scope-and-authorization.md` §3.1 例外） |
| 凭据条款出现处 | **1**（`credential-policy.md`，其余文件只引用） |
| 文件总数 | 75（md 65；知识库 43 篇 + 索引；规则 16） |

说明：知识库方法文档中的 `Cookie:`、`key=` 为占位示例（如 `Cookie: <会话>`），不含真实值；P0 红线头已同步加入双账号例外指针。

## 已知限制

- 未单独成篇但已并入：401-403 → `authbypass-test.md`；clickjacking → `csrf-test.md`；csp → `xss-test.md`；email-header → `http-host-header-test.md`；hpp → `api-gateway-test.md`；dns-rebinding → `ssrf-test.md`；dangling-markup → `xss-test.md` mXSS 节。
- 仍未覆盖：xslt、llm-security；需要时单独补，不要当成"已覆盖"。
- 矩阵中的"第二账号"列需用户提供账号才能填。
- FOFA 与 Playwright 为可选组件，缺失不影响规则与技能；Playwright 首次运行需联网 `npx @playwright/mcp`。
- 客户端（App/小程序）黑盒未收录，当前只覆盖 Web 与 Electron 链。
