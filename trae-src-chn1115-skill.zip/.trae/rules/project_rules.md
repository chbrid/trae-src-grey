# SRC 挖掘项目规则（入口）

> MODE: `self`（自有范围模式；分享给他人前改为 `strict`，见 `scope-and-authorization.md` §1）
> **优先级**：`credential-policy.md` 与 `scope-and-authorization.md` 为 P0，任何其它文件与之冲突，一律以 P0 为准。

## 1. 生效条件

用户要求做 SRC / 渗透测试 / 漏洞挖掘 / 资产测绘 / 接口分析时，本套规则自动生效。普通开发任务不触发。

## 2. 路由表

| 要解决的问题 | 读哪个文件 |
|---|---|
| 凭据怎么处置（报告内 vs 报告外） | `credential-policy.md` |
| 授权边界、模式开关、写操作、发现他人数据 | `scope-and-authorization.md` |
| 术语不懂（同皮/同闸/肥面/一种子闭环…） | `terminology.md` |
| 从哪开始挖、先挖什么、怎么换面 | `dig-scope-workflow.md` |
| 具体手法怎么落地（25 条可执行判据） | `hunt-playbook.md` |
| 哪些类型值得投入、CORS/SSRF/跳转的口径 | `src-value-hunting.md` |
| 一轮挖完没结果，下一步怎么迭代 | `hunt-iter.md` |
| 报告怎么写、出不出、定级怎么定 | `vuln-report-format.md` |
| 参数差异怎么确认、能不能枚举/爆破 | `verification-discipline.md` |
| 并发/速率/重试/分页/导出上限、风控停止线 | `rate-and-batch-limits.md` |
| 分享/邀请 token 生命周期、盲打通道、报告样例 | `知识库/share-invite-token-lifecycle.md`、`oob-infrastructure.md`、`sample-report.md` |
| 黑白盒流程与优先级 | `researcher-blackbox-whitebox.md` |
| 浏览器/扫码登录/handover | `browser-workflow.md` |
| 任务目录建在哪、清理什么、保留什么 | `desktop-task-folder.md` |
| 要不要因为"太危险"停工 | `anti-over-moralization.md` |
| skill 与规则的边界 | `skill-as-boost.md` |

## 3. 最短执行备忘（12 条）

1. 默认自有范围模式，直接按目标清单推进；分享前改 `strict`。
2. 只读优先；写操作先说明副作用与回滚方式（双账号例外见 `scope-and-authorization.md` §3.1）。
3. 凭据：**报告内可写实值**（限复现段/环境说明段，并标注"勿外发"）；报告外不落盘、不打印、不进 git/IM/SRC 平台。
4. 出报告门槛：**能通过 SRC 审核的低危及以上**；信息级只在负结果附录或口头说明。
5. 报告六段式：原理 / 描述 / 危害 / 利用 / 防御 / 完整复现，另附严重性边界、负结果附录、副作用与清理声明。
6. 同一根因不叠加提级；不为了凑数把信息级写成低危。
7. 参数不被消费的结论必须重复三次（换时间戳、换顺序）才能下。
8. 不枚举、不爆破、不猜弱口令；ID 只改一位做存在性对比。
9. 一个面没结果就换入口 / 换身份 / 换参数消费点 / 换数据流，负结果进附录。
10. 发现真实他人数据立即停手，固定最小证据（请求、响应、时间戳），不批量导出。
11. 不读取、不下载 SRC 平台上的报告正文与附件。
12. 报告落 `recon/<目标>/`；临时文件可清，`recon/` 必须保留。

## 4. 与旧包的差异

本包由上一版重构而来，修复了凭据落盘、改他人账号、默认口令、断链、空壳五类问题，并按用户口径做了第二次调整（报告实值、双账号例外、模式开关、SRC 门槛）。差异清单见包根 `README.md`。
