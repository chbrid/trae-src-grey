# 知识库索引（43 篇）

> 用法：先看 `打穿短表.md` 找方向，再按行内指针打开对应专题。所有指针必须能在本目录找到同名文件。
> P0 口径（凭据、写操作、他人账号）统一见 `.trae/rules/credential-policy.md` 与 `scope-and-authorization.md`。

## 流程与方法（8）

| 文件 | 一句话 |
|---|---|
| `recon-methodology.md` | 资产测绘：CT、被动 DNS、指纹、归并 |
| `打穿短表.md` | 一页式方向表：现象 → 打法 → 命中判据 → 不成立判据 |
| `auth-matrix.md` | 角色 × 接口 × 返回差异矩阵模板（含填好样例） |
| `evidence-fixed.md` | 证据最小集、脱敏规则、归档（含填好样例） |
| `side-effects-cleanup.md` | 目标侧副作用登记与清理（含填好样例） |
| `sample-report.md` | 六段式 + 三附录的完整样例（占位数据） |
| `js-reverse-guide.md` | 前端产物分析、接口抽取、加密定位 |
| `waf-bypass.md` | WAF 识别与编码绕过（只做非破坏性） |

## 访问控制（6）

| 文件 | 一句话 |
|---|---|
| `idor-test.md` | 越权：id 改一位、列表/详情闸不一致、归属缺失 |
| `authbypass-test.md` | 鉴权绕过：未登录前缀、签发口、状态字段 |
| `oauth-jwt-test.md` | OAuth/JWT：算法、kid、scope、回调 |
| `share-invite-token-lifecycle.md` | 分享/邀请 token：签发、归属、撤销、过期、重放 |
| `http-host-header-test.md` | Host/X-Forwarded-Host 毒化与重置链 |
| `subdomain-takeover-test.md` | 子域接管：CNAME 悬空、托管指纹 |

## 注入与执行（11）

| 文件 | 一句话 |
|---|---|
| `injection-test.md` | SQL/NoSQL/命令/模板注入：触发、三判据、绕过与误报 |
| `crlf-injection-test.md` | 响应拆分 / Set-Cookie / 日志注入 |
| `csv-formula-injection-test.md` | 导出 CSV/Excel 公式注入 |
| `xxe-test.md` | XXE：外部实体、盲打、OOB |
| `jndi-injection-test.md` | JNDI/Log4j 类注入 |
| `deserialization-test.md` | Java/PHP/Python 反序列化 |
| `el-injection-test.md` | 表达式注入（SpEL/OGNL/EL） |
| `prototype-pollution-test.md` | 原型链污染 |
| `type-juggling-test.md` | 类型混淆与弱比较 |
| `graphql-test.md` | GraphQL：内省、批量、越权 |
| `api-gateway-test.md` | 网关/路由/鉴权头错配 |

## 文件与路径（4）

| 文件 | 一句话 |
|---|---|
| `path-traversal-lfi-test.md` | 路径穿越/任意文件读取（编码矩阵、Windows、备份清单、Ghostcat） |
| `file-upload-test.md` | 上传：类型/后缀/内容/存储策略 |
| `insecure-scm-test.md` | 源码/配置/备份泄露 |
| `dependency-confusion-test.md` | 依赖混淆：内部包名外发与私有源优先级 |

## 客户端与请求层（6）

| 文件 | 一句话 |
|---|---|
| `xss-test.md` | XSS：sink 定位、DOM 矩阵、CSP bypass、mXSS |
| `csrf-test.md` | CSRF：token、SameSite、状态变更 |
| `open-redirect-test.md` | 开放重定向：真实跳转才定级 |
| `http-smuggling-test.md` | 请求走私 |
| `cache-poisoning-test.md` | 缓存投毒与缓存欺骗 |
| `websocket-test.md` | WebSocket：鉴权、跨站、消息篡改 |

## 服务端与云（5）

| 文件 | 一句话 |
|---|---|
| `ssrf-test.md` | SSRF：厂商元数据、DNS rebinding、gopher、判定线 |
| `oob-infrastructure.md` | 盲打通道：interactsh、回收、证据固化、无回连降级 |
| `race-condition-test.md` | 竞态：并发窗口与一次性资源 |
| `cloud-ide-codex-rce-chain.md` | 公网编程台/Codex RPC 链 |
| `ghost-bits-cast-test.md` | 幽灵比特/类型转换类内存问题 |

## 信息与业务（3）

| 文件 | 一句话 |
|---|---|
| `info-leak-test.md` | 信息泄露分级与"能否推进下一步"判据 |
| `logic-test.md` | 业务逻辑：金额、名额、次数、状态机 |
| `agent-tool-exec-test.md` | AI 对话口工具真执行（非越狱） |

## 空壳处理记录

原包 14 个 3 行空壳：已补 `crlf-injection-test.md`、`csv-formula-injection-test.md`、`dependency-confusion-test.md`；`cors` 并入 `src-value-hunting.md` §2.6；`dns-rebinding` 并入 `ssrf-test.md`；`http2` 并入 `http-smuggling-test.md`；`dangling-markup` 并入 `xss-test.md` 的 mXSS 节。
仍未覆盖：401-403（`authbypass-test.md` 部分）、clickjacking、csp-bypass（`xss-test.md` 部分）、email-header、hpp、llm-security、xslt — 见包根 README「已知限制」。
