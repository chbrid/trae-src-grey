---
name: src-hunt
description: SRC/授权渗透测试工作流。用户要求对指定目标做资产测绘、接口清单、越权/注入/上传/SSRF/业务逻辑验证、证据固定或写漏洞报告时使用。不用于普通开发、代码审查或非授权测试。
---

# SRC 挖掘技能

配合 `.trae/rules/` 使用：**规则管口径，本技能管流程**。两者冲突时以 `credential-policy.md`、`scope-and-authorization.md` 为准。

## 1. 开工

1. 确认目标清单、动作级别（只读/可登录/可写）、时间窗；范围不清问一次。
2. 建 `recon/<目标>/`：`assets/`、`api.md`、`evidence/`、`negative.md`。
3. 记录三条基线：首页、登录页、明确的 404。

## 2. 一种子闭环

一个子域 / 一个 API 前缀 / 一个功能点，按顺序挖到"同皮同闸都试过"再换：

说清这摊 → 前端抽钥匙 → 匿名接口清单 → 四档标注（匿名/登录/实名/管理员）→ 参数消费点 → 对象归属 → 写操作（需授权）。

每步的具体做法与判据见 `.trae/rules/hunt-playbook.md`（25 条，A 定性 / B 免登录扩面 / C 鉴权归属 / D 令牌 / E 网关 / F 判定推进 / G 降级 / H 命中即停）；本技能只给顺序，不重复定义。
节奏与批量上限见 `.trae/rules/rate-and-batch-limits.md`；分享/邀请 token 见 `知识库/share-invite-token-lifecycle.md`；盲打通道见 `知识库/oob-infrastructure.md`；报告样例见 `知识库/sample-report.md`。

## 3. 对得上再开篇

| 现象 | 打开 |
|---|---|
| 详情/列表/导出接口带 id、uuid、orderNo | `知识库/idor-test.md` |
| 需要登录才能到业务层、有未登录前缀 | `知识库/authbypass-test.md` |
| 登录态矩阵（角色×接口） | `知识库/auth-matrix.md` |
| 登录/回调/JWT/scope | `知识库/oauth-jwt-test.md` |
| 路径参数吃 `../`、下载口吃文件名 | `知识库/path-traversal-lfi-test.md` |
| 上传口、对象存储、预签名 URL | `知识库/file-upload-test.md` |
| 参数进 SQL/命令/模板/表达式 | `知识库/injection-test.md` 与 `知识库/el-injection-test.md` |
| 图片/URL 参数被服务端请求 | `知识库/ssrf-test.md` |
| 富文本、昵称、备注回显 | `知识库/xss-test.md` |
| 金额、名额、次数、邀请码、审核状态 | `知识库/logic-test.md` |
| 回跳参数、callback、redirect_uri | `知识库/open-redirect-test.md` |
| sourcemap、配置文件、备份、内部地址 | `知识库/info-leak-test.md` |
| 云托管、编程台、Codex/RPC | `知识库/cloud-ide-codex-rce-chain.md` |
| AI 对话口能调工具 | `知识库/agent-tool-exec-test.md` |
| 其它方向 | `知识库/打穿短表.md` |

## 4. 验证

- 参数不被消费的结论必须三次确认（换时间戳、换顺序）。
- 不枚举、不爆破、不猜口令；ID 只改一位。
- 只做本地可重放验证；前端改状态不算。
- 详见 `verification-discipline.md`。

## 5. 报告

- 能过 SRC 审核的低危及以上：六段式 + 严重性边界 + 负结果附录 + 副作用与清理声明（`vuln-report-format.md`）。
- 全负：口头结论 + 覆盖缺口，不写报告。
- 信息级不升级成低危。

## 6. P0 红线

1. Cookie/Token/Key 在**报告内可写实值**（限复现段/环境说明段，标注"勿外发"）；报告外不落盘、不打印、不进 URL、不跨目标复用（`credential-policy.md`）。
2. 不改他人密码/绑定/密保；只证明接口接受参数即停。用户自有 A/B 双账号场景见 `scope-and-authorization.md` §3.1。
3. 不试默认口令、不爆破、不批量导出。
4. 发现真实他人数据立即停手，固定最小证据（`scope-and-authorization.md` §5）。

## 7. 结束

- 报告落 `recon/<目标>/`；临时文件可清，`recon/` 保留。
- 需要写操作/第二账号/短信时，列出来等授权。
