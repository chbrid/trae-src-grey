# 从 Grok 移植到 TRAE（本包说明）

本包不是原英文手册的翻译，而是按 TRAE 的规则/技能/MCP 机制重写的一套：**规则管口径，技能管流程，知识库管手法，MCP 管测绘与浏览器**。

## 一、机制对应

| Grok 侧 | TRAE 侧 | 说明 |
|---|---|---|
| 一段长系统提示词 | `.trae/rules/` 下的 md | 按主题拆开，project_rules 做入口路由 |
| 一次性对话 | `skills/src-hunt/SKILL.md` | 自动触发；触发条件写在 description |
| 知识库附件 | `skills/src-hunt/知识库/` | 37 篇，索引见该目录 README |
| 工具调用 | `.trae/mcp.json` 的 fofa / playwright | 可选；没有不影响规则生效 |
| 会话状态 | 浏览器 + `recon/<目标>/` | 会话不落盘，证据落 recon |

## 二、安装

1. 复制 `skills/src-hunt` → `%USERPROFILE%\.trae-cn\skills\src-hunt`
2. 复制 `mcp-servers/fofa_MCP` → `%USERPROFILE%\.trae-cn\mcp-servers\fofa_MCP`
3. 复制 `bin/playwright-dual-slot.mjs` → `%USERPROFILE%\.trae-cn\bin\`
4. 复制 `.trae/rules/` 下全部 md 到项目根 `.trae/rules/`；`.trae/mcp.json` 作模板，把 `<用户名>` 换成本机用户名（Windows 路径用双反斜杠）
5. 填 FOFA Key：`mcp.json` 的 `mcpServers.fofa.env` 或 `fofa_MCP/.env`（都留空则测绘不可用）
6. 重启 TRAE 会话，确认技能列表出现 `src-hunt`

## 三、可选组件

- **playwright**：`node <本机>\.trae-cn\bin\playwright-dual-slot.mjs`，双 CDP 槽 9222/9223。**使用独立 profile（`slot-<port>`），不含用户真实登录态**；需要登录时走浏览器 handover。
- **fofa**：三账号自动切换；已限流的号会被排除，不再重试；403 视为鉴权问题而非限流。

## 四、不使用 MCP 时

删掉 `mcp.json` 中对应条目即可，规则与技能不受影响，仅失去批量测绘与双槽浏览器。

## 五、凭据

本包不含任何真实 Key、Cookie、Token。`.env` 为空模板，`mcp.json` 的 env 全空。填写后不要把文件发出去。
